//file Hash.cpp
//@version lab4
//@author Duong H Chau

#include "Hash.h"

//default constructor
Hash::Hash(){}
//default destructors
Hash::~Hash(){}
