//file nodedata.cpp
//@version lab4
//@author Duong H Chau

#include "nodedata.h"

NodeData::NodeData(){}

NodeData::~NodeData(){}
