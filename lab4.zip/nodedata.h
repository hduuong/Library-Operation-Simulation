//---------------------------------------------------------------------------
/*  NodeData Class: is made to simplify the Hash class
                    gives the Hash and its children a comment object to workwith
*/
//---------------------------------------------------------------------------

#ifndef NODEDATA_H
#define NODEDATA_H
#include <string>
#include <iostream>
#include <fstream>
using namespace std;
class NodeData {
public:
   NodeData();          // default constructor
   ~NodeData();         // destructor     

private:
};

#endif
